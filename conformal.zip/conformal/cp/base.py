
class ConformalPredictor(object):
    u"""Base class for conformal predictors."""
    def __call__(self, example, eps):
        u"""Extending classes should implement this method to return predicted values
        for a given example and significance level."""
        #print ("BASE ::::EXAMPLE ",self.example)
        raise NotImplementedError

    def predict(self, example, eps):
        u"""Extending classes should implement this method to return a prediction object.
        for a given example and significance level."""
        raise NotImplementedError
