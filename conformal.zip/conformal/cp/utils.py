u"""Utils module contains various utility functions that are used in different parts
of the conformal prediction library.
"""

from __future__ import absolute_import
import numpy as np
import Orange
from Orange.data import Table
from Orange.preprocess import *
import math

def get_instance(data, i):
    u"""Extract a single instance from data as a test instance and return the remainder as a training set."""
    #domain = data.domain
    #data=np.array(data)
    # print "In get_instace"
    # print "type ", type(data)
    train, test = None, data[i]
    if i == 0: 
        train = Table(data[1:])
    elif i == len(data)-1: 
        train = Table(data[:-1])
    else:

        train = Table(data.domain, data[:i] + data[i+1:])

    return train, test

def split_data(data, a, b):
    u""""Split data in approximate ratio a:b."""
    k = a*len(data)//(a+b)
    return data[:k], data[k:]

def shuffle_data(data):
    u"""Randomly shuffle data instances."""
    dataset=np.array(data)
    shuffle_dataset = dataset[np.random.permutation(len(dataset))]
    return shuffle_dataset
    #return Orange.data.Table(data.domain,dataset[np.random.permutation(len(dataset))])

"""
Data-manipulation utilities.
"""
#import numpy as np
#import bottleneck as bn
#Taken from orange 3.0

def one_hot(values, dtype=float):
    """Return a one-hot transform of values

    Parameters
    ----------
    values : 1d array
        Integer values (hopefully 0-max).

    Returns
    -------
    result
        2d array with ones in respective indicator columns.
    """
    return np.eye(np.max(values) + 1, dtype=dtype)[np.asanyarray(values, dtype=int)]

def mySpanTransform(tab):

    #colIdx = 0
    for colIdx in range(len(tab.domain.attributes)):
        valueList = []
        for ex in tab:
            elemValue = ex[colIdx].value
            valueList.append(elemValue)
        #print valueList
        minv = min(valueList)
        maxv = max(valueList)
        for ex in tab:
            ex[colIdx] = (ex[colIdx] - minv)/(maxv - minv)

    return tab

def transformExToList(ex):
    resList = []
    for elem in ex:
        resList.append(elem.value)
    resList = resList[0:len(resList)-1]
    return resList

def transformTableToList(table):
    resMat = []
    for row in table:
        newRow = transformExToList(row)
        resMat.append(newRow)
    return resMat

def getRespVect(data):
    respVect = []
    for ex in data:
        respVect.append(ex.get_class())
    return respVect
