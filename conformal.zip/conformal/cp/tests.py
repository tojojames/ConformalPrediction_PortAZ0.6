u"""Unittests for conformal prediction."""

from __future__ import with_statement
from __future__ import division
from __future__ import absolute_import
from unittest import TestCase
from builtins import object
import os

import numpy as np
import sklearn.svm as skl_svm
from sklearn.ensemble import RandomForestRegressor

import orange
import Orange
from Orange.classification.bayes import NaiveLearner as NaiveBayesLearner
from Orange.core import LogRegLearner as LogisticRegressionLearner
from Orange.core import SVMLearner,kNNLearner

# import AZOrangeConfig as AZOC
# from AZutilities import miscUtilities
# from trainingMethods import AZorngCvBayes
from trainingMethods import AZorngRF,AZorngCvSVM

from Orange.data import Table, Domain, Instance
###### Missing RowInstance

from AZutilities.Mahalanobis import euclidean as Euclidean
from Orange.distance.instances import Mahalanobis as MahalanobisDistance
######Missing Cosine

######Missing Normalize
# from Orange.regression import LinearRegressionLearner, KNNRegressionLearner, SVRLearner, RandomForestRegressionLearner
from Orange.regression.linear import LinearRegressionLearner
#from orange import kNNLearner as KNNRegressionLearner
from Orange.classification.knn import kNNLearner as KNNRegressionLearner
from Orange.ensemble.forest import RandomForestLearner as RandomForestRegressionLearner
#Add Finish TJ

from cp.classification import TransductiveClassifier, InductiveClassifier, CrossClassifier, LOOClassifier
from cp.evaluation import LOOSampler, CrossSampler, RandomSampler, run, calibration_plot, run_train_test, ResultsClass, \
    ResultsRegr
from cp.nonconformity import InverseProbability, AbsError, KNNDistance, KNNFraction, AbsErrorKNN, ProbabilityMargin, \
    AvgErrorKNN, AbsErrorNormalized, LOORegrNC, LOOClassNC, SVMDistance, AbsErrorRF, ExperimentalNC, ErrorModelNC
from cp.regression import InductiveRegressor, CrossRegressor, LOORegressor
from cp.utils import get_instance, split_data, shuffle_data, mySpanTransform
from io import open
import numpy as np

class TestTransductive(TestCase):
    def test_inverse_probability(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        train, test = get_instance(tab, 0)
        train =Orange.data.Table(tab.domain,train)
        tcp = TransductiveClassifier(InverseProbability(AZorngRF.RFLearner()), train)
        pred = tcp(test, 0.1)
        #self.assertEqual(pred, ['High', 'Low'])

        train, test = get_instance(tab, 0)
        train =Orange.data.Table(tab.domain,train)
        tcp = TransductiveClassifier(InverseProbability(AZorngRF.RFLearner()))
        tcp.fit(train)
        pred = tcp(test, 0.1)
        print "pred ", pred
        self.assertEqual(pred, ['High', 'Low'])
      

    def test_nearest_neighbours(self):    ###NOT WORKING
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        train, test = get_instance(tab, 0)
        train =Orange.data.Table(tab.domain,train)
        tcp = TransductiveClassifier(KNNDistance(Euclidean), train)
        pred = tcp(test, 0.1)
        print "pred ", pred
        ##self.assertEqual(pred, [u'Iris-setosa'])

    def test_validate_transductive(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        eps = 0.1
        correct, num, all = 0, 0, len(tab)
        for i in xrange(all):
            train, test = get_instance(tab, i)
            #train =Orange.data.Table(tab.domain,train)
            tcp = TransductiveClassifier(InverseProbability(AZorngRF.RFLearner()), train)
            pred = tcp(test, eps)
            if test.get_class() in pred: correct += 1
            num += len(pred)
        #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.01)


class TestInductive(TestCase):
    def setUp(self):
        self.tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        #self.tab = Table(u'iris')
        train, self.test = get_instance(self.tab, 0)
        train = Orange.data.Table(self.tab.domain,train)
        self.train, self.calibrate = split_data(shuffle_data(train), 2, 1)
        self.train = Orange.data.Table(self.tab.domain,self.train.tolist())
        self.calibrate = Orange.data.Table(self.tab.domain,self.calibrate.tolist())

    # def test_inverse_probability(self):
    #     icp = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()), self.train, self.calibrate)
    #     pred = icp(self.test, 0.01)
    #     ##self.assertEqual(pred, [u'Iris-setosa', u'Iris-versicolor', u'Iris-virginica'])
    #     #self.assertEqual(pred, ['High', 'Low'])

    #     icp = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()))
    #     icp.fit(self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #print pred
    #     #self.assertEqual(pred, ['High', 'Low'])

    # def test_nearest_neighbours(self):
    #     icp = InductiveClassifier(KNNDistance(Euclidean), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    # def test_validate_inductive(self):
    #     eps = 0.1
    #     correct, num, all = 0, 0, len(self.tab)
    #     for i in xrange(all):
    #         train, test = get_instance(self.tab, i)
    #         train, calibrate = split_data(shuffle_data(train), 2, 1)
    #         train = Orange.data.Table(self.tab.domain,train.tolist())
    #         calibrate = Orange.data.Table(self.tab.domain,calibrate.tolist())

    #         icp = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()), train, calibrate)
    #         pred = icp(test, eps)
    #         if test.get_class() in pred: correct += 1
    #         num += len(pred)
    #     #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.01)

    def test_validate_regression(self):
        tab = Table(u'housing.tab')  #changed to regression dataset
        print "INitial data ", tab[0] 
        eps = 0.1
        correct, num, all = 0, 0, len(tab)
        for i in xrange(all):
            train, test = get_instance(tab, i)
            print "before ", len(train[0]), train[0]
            train = Orange.data.Table(tab.domain,train)
            train, calibrate = split_data(shuffle_data(train), 2, 1)
            #print "after split train ", train

            print "train first instance", len(train[0]), train 
            train = Orange.data.Table(tab.domain, train.tolist())
            calibrate = Orange.data.Table(tab.domain,calibrate.tolist()) 
            #train = Orange.data.Table(self.tab.domain,train.tolist())
            #calibrate = Orange.data.Table(self.tab.domain,calibrate.tolist())
            
            #print "Before IndReg train ", train
            #print train[0] 
            icr = InductiveRegressor(AbsError(AZorngRF.RFLearner()), train, calibrate)
            y_min, y_max = icr(test, eps)
            if y_min <= test.y <= y_max: correct += 1
            num += y_max - y_min
        #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.02)


class TestCross(TestCase):
    def test_cross_classification(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        train, test = get_instance(tab, 0)
        #train = Orange.data.Table(tab.domain,train)
        train = shuffle_data(train)
        train = Orange.data.Table(tab.domain,train.tolist())
        #print train.domain
        ccp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 3, train)
        pred = ccp(test, 0.1)
        #self.assertEqual(pred, [u'Iris-setosa'])

        ccp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 3)
        ccp.fit(train)
        #print (test,len(test))
        pred = ccp(test, 0.1)
        #self.assertEqual(pred, [u'Iris-setosa'])

    def test_loo(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        train, test = get_instance(tab, 0)

        train = Orange.data.Table(tab.domain,train)
        loocp = LOOClassifier(InverseProbability(AZorngRF.RFLearner()), train)
        pred = loocp(test, 0.1)
        print pred
        #self.assertEqual(pred, [u'Iris-setosa'])

        # train, test = get_instance(Table(u'housing'), 0)        ###To avoid using different dataset
        tab = Table(u'housing.tab')
        train, test = get_instance(tab, 0)
        train = Orange.data.Table(tab.domain,train)
        loocr = LOORegressor(AbsError(AZorngRF.RFLearner()), train)
        lo, hi = loocr(test, 0.1)
        #self.assertLess(hi-lo, 20)

    def test_validate_cross_classification(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        eps = 0.1
        correct, num, all = 0, 0, len(tab)
        for i in xrange(all):
            train, test = get_instance(tab, i)
            train = Orange.data.Table(tab.domain,train)
            ccp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 5, train)   
            pred = ccp(test, eps)
            if test.get_class() in pred: correct += 1
            num += len(pred)
        #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.02)

    def test_validate_cross_regression(self):                                                       ### Need rework on it
        data_table = Table(u'housing.tab')
        tab = shuffle_data(data_table)
        tab = Orange.data.Table(data_table.domain,tab.tolist())
        eps = 0.1
        correct, num, all = 0, 0, len(tab)
        for i in xrange(all):
            train, test = get_instance(tab, i)
            train_shuffle = shuffle_data(Orange.data.Table(tab.domain,train))
            train_shuffle = Orange.data.Table(tab.domain,train_shuffle.tolist())
            #print (train_shuffle.domain)
            ccr = CrossRegressor(AbsError(AZorngRF.RFLearner()), 2, train_shuffle)      #change the fold from 2 to 5
            y_min, y_max = ccr(test, eps)
            if y_min <= test.get_class() <= y_max: correct += 1
            num += y_max - y_min
        #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.02)


class TestMondrian(TestCase):
    def test_transductive(self):
        cpm = TransductiveClassifier(InverseProbability(AZorngRF.RFLearner()), mondrian=True)
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        rm = run(cpm, 0.1, LOOSampler(tab))
        #self.assertGreater(rm.accuracy(), 0.85)
        #self.assertGreater(rm.singleton_criterion(), 0.0564)

    def test_inductive(self):
        cpm = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()), mondrian=True)
        rm = run(cpm, 0.1, LOOSampler(Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')))
        #print ("Done...")
        ##self.assertGreater(rm.accuracy(), 0.85)
        #self.assertGreater(rm.accuracy(), 0.12)
        #self.assertGreater(rm.singleton_criterion(), 0.12)

    def test_cross(self):
        cpm = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 4, mondrian=True)
        rm = run(cpm, 0.1, LOOSampler(Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')))
        #self.assertGreater(rm.accuracy(), 0.85)
        #self.assertGreater(rm.singleton_criterion(), 0.85)

    # def test_accuracy(self):
    #     #tab = Table(u'iris')[:120]
    #     tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
    #     results = []
    #     for m in [False, True]:
    #         cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 2, mondrian=m)
    #         r = run(cp, 0.2, LOOSampler(tab), rep=10)
    #         res = [r.accuracy(y) for y in xrange(3)]
    #         results.append(res)
    #         print r.accuracy(), res
    #     span = max(results[0])-min(results[0])
    #     span_mondrian = max(results[1])-min(results[1])
    #     #self.assertLess(span_mondrian, span)


class TestUSPS(TestCase):
    def test_nonexchangeability(self):
        tab = Table(os.path.join(os.path.dirname(__file__), u'../data/usps.tab'))
        train, test = split_data(tab, 7291, 2007)
        test = test[:200]
        train, calibrate = split_data(train, 3, 1)
        #train = Orange.data.Table(tab.domain,train)
        #calibrate = Orange.data.Table(tab.domain,calibrate)
        #print (train.domain)
        icp = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()), Table(train), Table(calibrate)) 
        err = [inst.get_class() not in icp(inst.x, 0.1) for inst in test]
        #self.assertGreater(sum(err)/len(test), 0.13)


class TestClassificationNC(TestCase):
    def setUp(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        self.train, self.test = get_instance(tab, 0)
        self.train = Orange.data.Table(tab.domain,self.train)
        self.train, self.calibrate = split_data(shuffle_data(self.train), 2, 1)
        self.train = Orange.data.Table(tab.domain,self.train.tolist())
        self.calibrate = Orange.data.Table(tab.domain,self.calibrate.tolist())
        #print ("Here type....",type(self.train))
        #print (self.train)
        
    def test_model_based(self):
        #self.train = Orange.data.Table(self.tab.domain,self.train)
        #self.calibrate = Orange.data.Table(self.tab.domain,self.calibrate)
        print (InverseProbability(AZorngCvSVM.CvSVMLearner(returnDFV=True)))
        icp = InductiveClassifier(InverseProbability(AZorngCvSVM.CvSVMLearner(returnDFV=True)), self.train, self.calibrate)
        pred = icp(self.test, 0.1)
        #self.assertEqual(pred, [u'Iris-setosa'])

        icp = InductiveClassifier(ProbabilityMargin(AZorngCvSVM.CvSVMLearner(returnDFV=True)), self.train, self.calibrate)
        pred = icp(self.test, 0.1)
        #self.assertEqual(pred, [u'Iris-setosa'])

    # def test_knn_speed(self):
    #     tab = Table(os.path.join(os.path.dirname(__file__), u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt'))
    #     train, calibrate = RandomSampler(tab, 2, 1).next()
    #     self.train = Orange.data.Table(tab.domain,self.train)
    #     self.calibrate = Orange.data.Table(tab.domain,self.calibrate)
    #     icp = InductiveClassifier(KNNDistance(Euclidean), train, calibrate)

    # def test_knn_distance(self):
    #     icp = InductiveClassifier(KNNDistance(Euclidean), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    #     icp = InductiveClassifier(KNNDistance(Cosine, 5), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    #     from Orange.distance import Mahalanobis
    #     icp = InductiveClassifier(KNNDistance(Mahalanobis, 5), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    #     from Orange.distance import MahalanobisDistance
    #     Mah = MahalanobisDistance(self.train)
    #     icp = InductiveClassifier(KNNDistance(Mah, 5), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    # def test_knn_fraction(self):
    #     icp = InductiveClassifier(KNNFraction(Euclidean, 10), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    #     icp = InductiveClassifier(KNNFraction(Euclidean, 10, weighted=True), self.train, self.calibrate)
    #     pred = icp(self.test, 0.1)
    #     #self.assertEqual(pred, [u'Iris-setosa'])

    # def test_LOOClassNC(self):
    #     for incl in [False, True]:
    #         for rel in [False, True]:
    #             for neigh in [u'fixed', u'variable']:
    #                 nc = LOOClassNC(NaiveBayesLearner(), Euclidean, 20,
    #                                 relative=rel, include=incl, neighbourhood=neigh)
    #                 icp = InductiveClassifier(nc, self.train, self.calibrate)
    #                 pred = icp(self.test, 0.1)
    #                 print pred
    #                 #self.assertEqual(pred, [u'Iris-setosa'])

    #     icp = InductiveClassifier(LOOClassNC(NaiveBayesLearner(), Euclidean, 20))
    #     r = run(icp, 0.1, CrossSampler(Table(u'iris'), 4))
    #     self.assertGreater(r.accuracy(), 0.85)
    #     self.assertGreater(r.singleton_criterion(), 0.8)

    # def test_SVM(self):
    #     dataset = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
    #     #iris = Table(u'iris')
    #     tab = Table(dataset[50:], dataset[50:]-1)  # versicolor, virginica
    #     # clear cases
    #     train, test = get_instance(tab, 30)
    #     train, calibrate = RandomSampler(train, 2, 1).next()
    #     icp = InductiveClassifier(SVMDistance(skl_svm.SVC()), train, calibrate)
    #     pred = icp(test.x, 0.1)
    #     #self.assertEqual(pred, [u'v1'])
    #     train, test = get_instance(tab, 85)
    #     train, calibrate = RandomSampler(train, 2, 1).next()
    #     icp = InductiveClassifier(SVMDistance(skl_svm.SVC()), train, calibrate)
    #     pred = icp(test.x, 0.1)
    #     #self.assertEqual(pred, [u'v2'])
    #     # border case
    #     train, test = get_instance(tab, 27)
    #     train, calibrate = RandomSampler(train, 2, 1).next()
    #     icp = InductiveClassifier(SVMDistance(skl_svm.SVC()), train, calibrate)
    #     pred = icp(test.x, 0.2)
    #     #self.assertEqual(pred, [])
    #     pred = icp(test.x, 0.01)
    #     #self.assertEqual(pred, [u'v1', u'v2'])

    # def test_nc_type(self):
    #     nc_class = InverseProbability(AZorngRF.RFLearner())
    #     nc_regr = AbsError(LinearRegressionLearner())
    #     TransductiveClassifier(nc_class)
    #     #self.assertRaises(AssertionError, TransductiveClassifier, nc_regr)
    #     InductiveClassifier(nc_class)
    #     #self.assertRaises(AssertionError, InductiveClassifier, nc_regr)
    #     CrossClassifier(nc_class, 5)
    #     #self.assertRaises(AssertionError, CrossClassifier, nc_regr, 5)


class TestRegressionNC(TestCase):
    def setUp(self):
        tab = Table(u'housing')
        self.train, self.test = get_instance(tab, 0)
        #print (self.train[np.random.permutation(len(self.train))])
        self.train, self.calibrate = split_data(shuffle_data(self.train), 2, 1)
        #self.train, self.calibrate = split_data(data.shuffle(self.train), 2, 1)
        self.train = Table(tab.domain,self.train.tolist())
        self.calibrate =Table(tab.domain,self.calibrate.tolist())
   

        # print "After normalization "
        # print tab[1][10].value


    # def test_abs_error_normalized(self):
    #     tab = Table(u'housing.tab')
    #     #print ("Table_domain",tab.domain)

    #     #transformer = orange.NormalizeContinuous()
    #     #normalizer = Normalize(zero_based=True, norm_type=Normalize.NormalizeBySpan)
    #     #tab = normalizer(tab)

    #     tab = mySpanTransform(tab)

    #     icr = InductiveRegressor(AbsError(LinearRegressionLearner()))
    #     icr_knn = InductiveRegressor(AbsError(KNNRegressionLearner(k=4)))
    #     icr_norm = InductiveRegressor(AbsErrorNormalized(KNNRegressionLearner(k=4), Euclidean, 4, exp=False))
    #     icr_norm_exp = InductiveRegressor(AbsErrorNormalized(KNNRegressionLearner(k=4), Euclidean, 4, exp=True))
    #     icr_norm_rf = InductiveRegressor(AbsErrorNormalized(KNNRegressionLearner(k=4), Euclidean, 4,
    #                                                         rf=RandomForestRegressor()))

    #     r, r_knn, r_norm, r_norm_exp, r_norm_rf = ResultsRegr(), ResultsRegr(), ResultsRegr(), ResultsRegr(), ResultsRegr()
    #     eps = 0.05


    #     for rep in xrange(10):
    #         for train, test in CrossSampler(tab, 10):
    #             train, calibrate = RandomSampler(train, len(train)-100, 100).next()
    #             print "train type ", type(train)
    #             r.concatenate(
    #                 (icr, eps, train, test, calibrate))
    #             r_knn.concatenate(run_train_test(icr_knn, eps, train, test, calibrate))
    #             r_norm.concatenate(run_train_test(icr_norm, eps, train, test, calibrate))
    #             r_norm_exp.concatenate(run_train_test(icr_norm_exp, eps, train, test, calibrate))
    #             r_norm_rf.concatenate(run_train_test(icr_norm_rf, eps, train, test, calibrate))

    #     print r.median_range(), r.interdecile_mean(), 1-r.accuracy()
    #     print r_knn.median_range(), r_knn.interdecile_mean(), 1-r_knn.accuracy()
    #     print r_norm.median_range(), r_norm.interdecile_mean(), 1-r_norm.accuracy()
    #     print r_norm_exp.median_range(), r_norm_exp.interdecile_mean(), 1-r_norm_exp.accuracy()
    #     print r_norm_rf.median_range(), r_norm_rf.interdecile_mean(), 1-r_norm_rf.accuracy()
    #     #self.assertGreater(r.accuracy(), 1-eps-0.03)
    #     #self.assertGreater(r_knn.accuracy(), 1-eps-0.03)
    #     #self.assertGreater(r_norm.accuracy(), 1-eps-0.03)
    #     #self.assertGreater(r_norm_exp.accuracy(), 1-eps-0.03)
    #     #self.assertGreater(r_norm_rf.accuracy(), 1-eps-0.03)
    #     u"""
    #     19.739259734 20.4378007266 0.051185770751
    #     22.225 22.2995182806 0.0474308300395
    #     15.0819327682 17.4239613065 0.048418972332
    #     14.3463382738 18.2976916462 0.0462450592885
    #     13.6700968865 18.0934053343 0.051185770751
    #     """

    # def test_LOORegrNC(self):
    #     for incl in [False, True]:
    #         for rel in [False, True]:
    #             for neigh in [u'fixed', u'variable']:
    #                 nc = LOORegrNC(AZorngRF.RFLearner(), Euclidean, 150,
    #                                relative=rel, include=incl, neighbourhood=neigh)
           
    #                 print "In loop"
    #                 print self.train, len(self.train)
    #                 print self.calibrate, len(self.calibrate)
    #                 icr = InductiveRegressor(nc, self.train, self.calibrate)
    #                 lo, hi = icr(self.test, 0.1)
    #                 print lo, hi
    #                 #self.assertLess(hi-lo, 20.0)

    #     tab = Table(u'housing')

    #     icr = InductiveRegressor(LOORegrNC(AZorngRF.RFLearner(), Euclidean, 150))
    #     r = run(icr, 0.1, CrossSampler(tab, 4))
    #     #self.assertGreater(r.accuracy(), 0.85)
    #     #self.assertLess(r.mean_range(), 15.0)

    # def test_error_model(self):
    #     for loo in [False, True]:
    #         icr = InductiveRegressor(ErrorModelNC(LinearRegressionLearner(), LinearRegressionLearner(), loo=loo),
    #                                  self.train, self.calibrate)
    #         lo, hi = icr(self.test, 0.1)
    #         #self.assertLess(hi-lo, 30.0)

    #     icr = InductiveRegressor(AbsError(RandomForestRegressionLearner()))
    #     r = run(icr, 0.1, CrossSampler(Table(u'housing'), 20))
    #     #self.assertGreater(r.accuracy(), 0.85)
    #     print r.accuracy(), r.median_range(), r.interdecile_mean()

    #     icr = InductiveRegressor(ErrorModelNC(RandomForestRegressionLearner(), LinearRegressionLearner()))
    #     r = run(icr, 0.1, CrossSampler(Table(u'housing'), 20))
    #     #self.assertGreater(r.accuracy(), 0.85)
    #     print r.accuracy(), r.median_range(), r.interdecile_mean()

    #     icr = InductiveRegressor(ErrorModelNC(RandomForestRegressionLearner(), LinearRegressionLearner(), loo=True))
    #     r = run(icr, 0.1, CrossSampler(Table(u'housing'), 20))
    #     #self.assertGreater(r.accuracy(), 0.85)
    #     print r.accuracy(), r.median_range(), r.interdecile_mean()

    def test_abs_error_rf(self):
        icr = InductiveRegressor(AbsErrorRF(RandomForestRegressionLearner(), RandomForestRegressor()),
                                 self.train, self.calibrate)
        lo, hi = icr(self.test, 0.1)
        #self.assertLess(hi-lo, 30.0)

        icr = InductiveRegressor(AbsErrorRF(LinearRegressionLearner(), RandomForestRegressor()),
                                 self.train, self.calibrate)
        lo, hi = icr(self.test, 0.1)
        #self.assertLess(hi-lo, 30.0)

        icr = InductiveRegressor(AbsErrorRF(RandomForestRegressionLearner(), RandomForestRegressor()))
        r = run(icr, 0.1, CrossSampler(Table(u'housing'), 10))
        #self.assertGreater(r.accuracy(), 0.85)
        print r.median_range(), r.interdecile_mean()

    # def test_abs_error_knn(self):
    #     icr = InductiveRegressor(AbsErrorKNN(Euclidean, 5), self.train, self.calibrate)
    #     lo, hi = icr(self.test, 0.1)
    #     #self.assertLess(hi-lo, 30.0)

    #     icr = InductiveRegressor(AbsErrorKNN(Euclidean, 5, average=True), self.train, self.calibrate)
    #     lo, hi = icr(self.test, 0.1)
    #     #self.assertLess(hi-lo, 30.0)

    #     icr = InductiveRegressor(AbsErrorKNN(Euclidean, 5, variance=True), self.train, self.calibrate)
    #     lo, hi = icr(self.test, 0.1)
    #     #self.assertLess(hi-lo, 30.0)

    # def test_avg_error_knn(self):
    #     ncm = AvgErrorKNN(Euclidean)
    #     #self.assertEqual(ncm.avg_abs_inv(6/5, [1, 2, 3, 4, 5]), (3, 3))
    #     for odd in [0, 1]:
    #         ys = np.random.uniform(0, 1, 10+odd)
    #         nc = 0.4
    #         lo, hi = ncm.avg_abs_inv(nc, ys)
    #         #self.assertGreater(ncm.avg_abs(lo-0.001, ys), nc)
    #         #self.assertLess(ncm.avg_abs(lo+0.001, ys), nc)
    #         #self.assertLess(ncm.avg_abs(hi-0.001, ys), nc)
    #         #self.assertGreater(ncm.avg_abs(hi+0.001, ys), nc)

    #     icr = InductiveRegressor(AvgErrorKNN(Euclidean, 10), self.train, self.calibrate)
    #     lo, hi = icr(self.test, 0.1)
    #     #self.assertLess(hi-lo, 30.0)

    #     r = run(InductiveRegressor(AvgErrorKNN(Euclidean, 10)), 0.1, RandomSampler(Table(u"housing"), 2, 1), rep=10)
    #     #self.assertFalse(any([np.isnan(w) for w in r.widths()]))

    # def test_validate_AvgErrorKNN(self):
    #     eps = 0.1
    #     correct, num, all = 0, 0, 0
    #     for it in xrange(10):
    #         tab =Table(u'housing')
    #         train, test = split_data(shuffle_data(tab), 4, 1)
    #         train, calibrate = split_data(shuffle_data(train), 3, 1)
    #         train = Table(tab.domain,train.tolist())
    #         calibrate = Table(tab.domain,calibrate.tolist())
    #         #test = Table(tab.domain,test.tolist())
    #         #print test
    #         icr = InductiveRegressor(AvgErrorKNN(Euclidean, 10), train, calibrate)
    #         for i, inst in enumerate(test):
    #             #print ("test....",dir(np.array(inst)),len(inst))
    #             y_min, y_max = icr(inst, eps)
                
    #             if not np.isnan(y_min):
    #                 if y_min <= inst.get_class() <= y_max: correct += 1
    #                 num += y_max - y_min
    #             all += 1
    #         print correct/all, num/all
    #     #self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.03)

    # def test_validate_AbsErrorKNN(self):
    #     eps = 0.1
    #     correct, num, all = 0, 0, 0
    #     for it in xrange(10):
    #         tab = Table(u'housing')
    #         train, test = split_data(shuffle_data(tab), 4, 1)
    #         train, calibrate = split_data(shuffle_data(train), 3, 1)
    #         train = Table(tab.domain,train.tolist())
    #         calibrate = Table(tab.domain,calibrate.tolist())
    #         icr = InductiveRegressor(AbsErrorKNN(Euclidean, 10, average=True, variance=True), train, calibrate)
    #         for i, inst in enumerate(test):
    #             y_min, y_max = icr(inst, eps)
    #             if y_min <= inst.get_class() <= y_max: correct += 1
    #             num += y_max - y_min
    #             all += 1
    #         print correct/all, num/all
    #     self.assertAlmostEqual(correct/all, 1.0-eps, delta=0.03)

    # def test_nc_type(self):
    #     nc_regr = AbsError(LinearRegressionLearner())
    #     nc_class = InverseProbability(AZorngRF.RFLearner())
    #     InductiveRegressor(nc_regr)
    #     #self.assertRaises(AssertionError, InductiveRegressor, nc_class)
    #     CrossRegressor(nc_regr, 5)
    #     #self.assertRaises(AssertionError, CrossRegressor, nc_class, 5)

    # def test_experimental(self):
    #     icr = InductiveRegressor(ExperimentalNC(RandomForestRegressor(n_estimators=20)), self.train, self.calibrate)
    #     r = run(icr, 0.1, CrossSampler(Table(u'housing'), 10))
    #     print r.accuracy(), r.median_range()


class TestSamplers(TestCase):
    def setUp(self):
        self.data = Table('iris')
        #print ("dataset",Table('iris'))
    def test_random(self):
        a, b = 3, 2
        s = RandomSampler(self.data, a, b)
        #print ("RandomSampler",s)
        #print ("sNEXT",)
        train, test = s.next()
        ##self.assertTrue(isinstance(train[0], RowInstance))
        #self.assertAlmostEqual(len(train)/len(test), a/b)

    def test_cross(self):
        folds = 7
        s = CrossSampler(self.data, k=folds)
        l = [(len(train), len(test)) for train, test in s]
        #self.assertEqual(len(l), folds)
        #self.assertTrue(all(a+b == len(self.data) for a, b in l))
        t = [b for a, b in l]
        #self.assertLessEqual(max(t)-min(t), 1)

        s = CrossSampler(self.data, k=folds)
        ids = frozenset(frozenset(inst.id for inst in test) for train, test in s)
        #self.assertEqual(len(ids), folds)

    def test_loo(self):
        s = LOOSampler(self.data)
        x = [len(test) == 1 for train, test in s]
        #self.assertTrue(all(x))
        #self.assertEqual(len(x), len(self.data))

    def test_repeat(self):
        rep = 5
        s = RandomSampler(self.data, 3, 2)
       
        #for train, test in s.repeat(5):
            #print "train and test"
            #print test
            #print len(test)
            # for inst in test:
            #     print "inst ", inst.id
        #print frozenset(inst.id for inst in test) 
        #print frozenset(frozenset(inst.id for inst in test) for train, test in s.repeat(5))
        ids = frozenset(frozenset(inst.id for inst in test) for train, test in s.repeat(5))
        #print (len(ids))
        #self.assertEqual(len(ids), 5)

        s = CrossSampler(self.data, 3)
        ids = frozenset(frozenset(inst.id for inst in test) for train, test in s.repeat(5))
        #self.assertEqual(len(ids), 15)


class TestEvaluation(TestCase):
    def test_run(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 5)
        r = run(cp, 0.1, RandomSampler(tab, 4, 1), rep=3)
        #self.assertEqual(len(r.preds), 3*1/5*len(tab))

        tab = Table(u'housing')
        cr = InductiveRegressor(AbsError(LinearRegressionLearner()))
        r = run(cr, 0.1, CrossSampler(tab, 4), rep=3)
        #self.assertEqual(len(r.preds), 3*len(tab))

    def test_run_train_test(self):
        dataset =Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        tab = Table(dataset.domain,shuffle_data(dataset).tolist())

        cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 4)

        r = run_train_test(cp, 0.1, tab[:100], tab[100:])

        cp = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()))
        r = run_train_test(cp, 0.1, tab[:50], tab[100:], tab[50:100])

    def test_accuracy(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 5)
        eps = 0.1
        r = run(cp, eps, LOOSampler(tab))
        acc = r.accuracy()
        #self.assertAlmostEqual(acc, 1-eps, delta=0.03)

    def test_time(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 5)
        r = run(cp, 0.1, LOOSampler(tab))
        r.time()

    def test_results_class(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        cp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 5)
        empty = run(cp, 0.5, RandomSampler(tab, 2, 1)).empty_criterion()
        #self.assertGreater(empty, 0.0)
        single = run(cp, 0.1, RandomSampler(tab, 2, 1)).singleton_criterion()
        #self.assertGreater(single, 0.8)
        multiple = run(cp, 0.01, RandomSampler(tab, 2, 1)).multiple_criterion()
        #self.assertGreater(multiple, 0.1)

        results = run(cp, 0.1, RandomSampler(tab, 2, 1))
        #self.assertGreater(results.singleton_correct(), 0.8)
        #self.assertGreater(results.confidence(), 0.9)
        #self.assertGreater(results.credibility(), 0.4)

    def test_results_regr(self):
        tab = Table(u'housing')
        cr = CrossRegressor(AbsErrorKNN(Euclidean, 10, average=True), 5)
        r1 = run(cr, 0.1, RandomSampler(tab, 2, 1))
        r5 = run(cr, 0.5, RandomSampler(tab, 2, 1))
        #self.assertGreater(r1.median_range(), r5.median_range())
        #self.assertGreater(r1.mean_range(), r5.mean_range())
        #self.assertGreater(r1.interdecile_range(), r5.interdecile_range())
        #self.assertGreater(r1.interdecile_mean(), r5.interdecile_mean())
        #self.assertGreater(r1.std_dev(), r5.std_dev())

    def test_pickle(self):
        import pickle
        train, test = RandomSampler(Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt'), 2, 1).next()
        train, cal = RandomSampler(train, 2, 1).next()
        ic = InductiveClassifier(InverseProbability(AZorngRF.RFLearner()))
        ic.fit(train, cal)
        #print ic(test[0].x, 0.1)
        with open(u'temp.cp',u'wb') as f:
            pickle.dump(ic, f)
        with open(u'temp.cp',u'rb') as f:
            ic2 = pickle.load(f)
        print ic2(test[0].x, 0.1)

    u"""
    def test_calibration_plot(self):
        data = Table("iris")
        nc = InverseProbability(AZorngRF.RFLearner())
        cp = InductiveClassifier(nc)
        calibration_plot(cp, data, rep=20)
    # """


class TestEfficiency(TestCase):
    def test_individual_classification(self):
        tab = Table(u'/disk1/tojjam/devConf/conformal_master/conformal/plots/RSVBulk.txt')
        train, test = get_instance(tab, 123)  # borderline case
        train = shuffle_data(train)
        train  = Table(tab.domain,train.tolist())
        ccp = CrossClassifier(InverseProbability(AZorngRF.RFLearner()), 3, train)
        pred = ccp.predict(test)
        cred, conf = pred.credibility(), pred.confidence()
        #self.assertLess(cred, 0.5)
        d = 1e-6
        #self.assertEqual(len(ccp(test.x, 1-(conf-d))), 1)
        #self.assertGreater(len(ccp(test.x, 1-(conf+d))), 1)
        #self.assertEqual(len(ccp(test.x, (cred+d))), 0)
        #self.assertGreater(len(ccp(test.x, (cred-d))), 0)

import unittest

# if __name__ == '__main__':
#     unittest.main()


# if __name__ == "__main__":
#         suite = unittest.TestLoader().loadTestsFromTestCase(RandomSampler)
#         unittest.TextTestRunner(verbosity=2).run(suite)

#         suite = unittest.TestLoader().loadTestsFromTestCase(CrossSampler)
#         unittest.TextTestRunner(verbosity=2).run(suite)

# if __name__ == "__main__":
#     suite = unittest.TestLoader().loadTestsFromTestCase(TestInductive)
#     unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestInductive)
    unittest.TextTestRunner(verbosity=2).run(suite)


print "============================================================"