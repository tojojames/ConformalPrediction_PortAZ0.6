# from trainingMethods import AZorngRF
# from AZutilities import dataUtilities 

# data = dataUtilities.DataTable("../conformal/plots/RSVBulk.txt")

# rf = AZorngRF.RFLearner(data)

# for ex in data:
#     predList = rf(ex, returnDFV = True)
#     print "Predicting ex"
#     pred = predList[0].value
#     print pred
#     prob = predList[1]
#     print prob
#     actual = ex.get_class().value
#     print actual
#     if pred != actual:
#         alpha = 1.0 + abs(prob)
#     else:
#         alpha = 1.0 - abs(prob)
#     print alpha

# data.save("../conformal/plots/RSVBulk.tab")

import Orange

# Load some data
iris = Orange.data.Table("iris.tab")
from AZutilities.Mahalanobis import euclidean as euclidean
#from Orange.core import ExamplesDistance_Euclidean as euclidean
# Construct a distance matrix using Euclidean distance
#euclidean = Orange.distance.Euclidean(iris)
distance = Orange.core.SymMatrix(len(iris))
def transformExToList(ex):
    resList = []
    for elem in ex:
        resList.append(elem.value)
    resList = resList[0:len(resList)-1]
    return resList

def transformTableToList(table):
    resMat = []
    for row in table:
        newRow = transformExToList(row)
        resMat.append(newRow)
    return resMat

#print (distance)
#print (len(iris))
for i in range(len(iris)):
   for j in range(i + 1):
        print ("IRIS_I",iris[i],"IRIS_J>>>>>>>>>>>>>>>>>>>>>>>>>",iris[j])
        distance[i, j] = euclidean(transformExToList(iris[i]), transformExToList(iris[j]))
        print ("DIstance",distance[i, j])

